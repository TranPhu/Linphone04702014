sudo make uninstall
make
sudo make install